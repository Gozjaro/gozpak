hello-raw fixture source file
